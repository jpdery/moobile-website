describe('Control/BarItem', function() {

});