Moobile is a Mobile UI Framework using MooTools!
------------------------------------------------

The API is currently not stable and not frozen. Don't use it in a production environment.

I'm currently polishing the API, as version 0.1 and documentation will be delivered early this year.

Stay tuned!